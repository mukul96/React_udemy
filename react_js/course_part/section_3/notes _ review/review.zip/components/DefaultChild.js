import React, { Component } from 'react';

class DefaultChild extends Component {

  render() {

    return (
      <div>
        Default
      </div>
    );

  }
}

export default DefaultChild;
