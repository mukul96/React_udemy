import React, { Component } from 'react';

class OtherChild extends Component {

  render() {

    return (
      <div>
        Other
      </div>
    );

  }
}

export default OtherChild;
